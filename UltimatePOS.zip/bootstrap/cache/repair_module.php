<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Repair\\Providers\\RepairServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Repair\\Providers\\RepairServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);